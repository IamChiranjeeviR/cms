## COLLEGE MANAGEMENT SYSTEM


How to run:
```
mvn spring-boot:run
```
