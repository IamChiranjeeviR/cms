package com.sgdc.cms.models;

public enum ApplicationStatus {
    PENDING,
    APPROVED,
    REJECTED
}
