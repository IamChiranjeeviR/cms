package com.sgdc.cms.dto;

/**
 * StudentGroupDto
 */

public class StudentGroupDto {
    private String name;

        
    public void setName(String name) {
        this.name = name;
    }   

    public String getGroupname() {
        return this.name;
    }
}
